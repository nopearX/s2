package avecmisenpage ;
import java.awt.GridLayout;

import javax.swing.*;

public class PerimetreObjet extends JPanel {
	// D�clarer les composants en tant qu'attribut
	protected JLabel lLongeur ;
	protected JLabel lLargeur ;
	protected JTextField txtLongeur ;
	protected JTextField txtLargeur ;
	protected JLabel lblResultat ;
	protected JLabel lblValResultat ;
	protected JButton bCalculer ;
	protected JButton bNettoyer ;

	// Constructeur 
	PerimetreObjet () {
		// Cr�er les composants
		lLongeur = new JLabel ("Longueur:");
		lLargeur = new JLabel ("Largeur:");
		txtLongeur = new JTextField (20);
		txtLargeur = new JTextField (20);
		lblResultat = new JLabel ("Resultat:");
		lblValResultat = new JLabel ("0");
		bCalculer = new JButton ("Calculer");
		bNettoyer = new JButton ("Nettoyer");	

		// Fixer la mise en page
		setLayout(new GridLayout (4, 2));

		// Centrer les labels
		lLongeur.setHorizontalAlignment(JLabel.CENTER);
		lLargeur.setHorizontalAlignment(JLabel.CENTER);
		lblResultat.setHorizontalAlignment(JLabel.CENTER);
	
		// Ajouter les composants
		add(lLongeur);
		add(txtLongeur);
		add(lLargeur);
		add(txtLargeur);
		add(lblResultat);
		add(lblValResultat);
		add(bCalculer);
		add(bNettoyer);
	}
	
	public static void main(String[] args) {
		// Creer une fenetre
		JFrame fenetre = new JFrame ("Perimetre");
		fenetre.setSize (300, 300);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Cr�er un panneau global
		PerimetreObjet perimetre = new PerimetreObjet();
			
		// Ajouter le bouton dans un des conteneurs de la fenetre
		fenetre.add(perimetre);
				
		// Afficher la fenetre
		fenetre.setVisible(true);
	}

}
