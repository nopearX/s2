package avecmisenpage ;
import java.awt.GridLayout;

import javax.swing.*;

public class PerimetreMain {

	public static void main(String[] args) {
		// Creer une fenetre
		JFrame fenetre = new JFrame ("Perimetre");
		fenetre.setSize (300, 300);
		fenetre.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		// Cr�er un panneau global
		JPanel perimetreMain = new JPanel();
		
		// Fixer la mise en page
		perimetreMain.setLayout(new GridLayout (4, 2));

		// Cr�er les composants
		JLabel lLongeur = new JLabel ("Longueur:");
		JLabel lLargeur = new JLabel ("Largeur:");

		JTextField txtLongeur = new JTextField (20);
		JTextField txtLargeur = new JTextField (20);
		JLabel lblResultat = new JLabel ("Resultat:");
		JLabel lblValResultat = new JLabel ("0");
		JButton bCalculer = new JButton ("Calculer");
		JButton bNettoyer = new JButton ("Nettoyer");
	
		// Centrer les labels
		lLongeur.setHorizontalAlignment(JLabel.CENTER);
		lLargeur.setHorizontalAlignment(JLabel.CENTER);
		lblResultat.setHorizontalAlignment(JLabel.CENTER);
		
		// Ajouter les composants
		perimetreMain.add(lLongeur);
		perimetreMain.add(txtLongeur);
		perimetreMain.add(lLargeur);
		perimetreMain.add(txtLargeur);
		perimetreMain.add(lblResultat);
		perimetreMain.add(lblValResultat);
		perimetreMain.add(bCalculer);
		perimetreMain.add(bNettoyer);
		
		// Ajouter le bouton dans un des conteneurs de la fenetre
		fenetre.add(perimetreMain);
				
		// Afficher la fenetre
		fenetre.setVisible(true);


	}

}
